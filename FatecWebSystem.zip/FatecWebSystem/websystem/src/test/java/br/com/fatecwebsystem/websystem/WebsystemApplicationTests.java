package br.com.fatecwebsystem.websystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
